import datetime

def date_string():
    return datetime.datetime.now().strftime("%d/%m/%y %H:%M:%S")
