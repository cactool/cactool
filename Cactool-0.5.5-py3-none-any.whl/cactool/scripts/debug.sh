FLASK_APP=cactool FLASK_ENV=development flask run
